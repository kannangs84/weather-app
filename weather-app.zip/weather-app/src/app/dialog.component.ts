import { Component, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
    selector: 'dialog-Component',
    templateUrl: 'dialog.component.html',
    styleUrls: ['./dialog.component.scss']
})

export class DialogComponent {
    
    constructor(
        @Inject(MAT_DIALOG_DATA) private data: any,
        public dialogRef: MatDialogRef<DialogComponent>) {}

    onNoClick(): void {
        this.dialogRef.close();
    }
}
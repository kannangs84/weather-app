import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json', 
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'DELETE, POST, GET, OPTIONS'})
};

//const apiUrl = "https://api.weatherbit.io/v2.0/current?city=Chennai,IN&key=ebc49895d1a2477785f7e23a30aeea8a";

@Injectable({
  providedIn: 'root'
})

export class WeatherService {

  constructor(private http: HttpClient) { }

  getSelectedCity (cityName): Observable<any>  {
    return this.http.get(
      environment.baseUrl +
      'current?city=' + cityName +
      '&key=' + environment.appId)
      .pipe(
        tap(city => console.log('Fetch city...', city)),
        catchError(this.handleError('getProducts', []))
      )
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
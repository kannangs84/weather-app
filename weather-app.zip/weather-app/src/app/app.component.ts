import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { WeatherService } from './services/weather.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import { DialogComponent } from './dialog.component';

export interface PeriodicElement {
  city: string;
  position: number;
  latitude: number;
  longitude: number;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, city: 'Ahmedabad', latitude: 23.02579, longitude: 72.58727},
  {position: 2, city: 'Bangalore', latitude: 12.97194, longitude: 77.59369},
  {position: 3, city: 'Chennai', latitude: 13.08784, longitude: 80.27847},
  {position: 4, city: 'Hyderabad', latitude: 17.38405, longitude: 78.45636},
  {position: 5, city: 'Kolkata', latitude: 22.56263, longitude: 88.36304},
  {position: 6, city: 'Mumbai', latitude: 19.07283, longitude: 72.88261},
  {position: 7, city: 'New Delhi', latitude: 28.63576, longitude: 77.22445},
  {position: 8, city: 'Pune', latitude: 18.51957, longitude: 73.85535},
  {position: 9, city: 'Surat', latitude: 21.19594, longitude: 72.83023},
];

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  title = 'weather-app';
  displayedColumns: string[] = ['position', 'city', 'avgTemp', 'avgWind'];
  dataSource1 = new MatTableDataSource(ELEMENT_DATA);
  city: any;

  constructor(private api: WeatherService, public dialog: MatDialog) { }

  ngOnInit() {
  }

  weatherDetails(city) {
    this.api.getSelectedCity(city)
    .subscribe(res => {
      if (res.data[0]) {
        this.city = res.data[0];
        this.dialog.open(DialogComponent, {
          height: '400px',
          width: '600px',
          data:{
            message: 'HelloWorld',
            buttonText: {
              cancel: 'Close'
            },
            cityWeather: this.city
          },
        });
      }      
    }, err => {
      console.log(err);
    });  
  }

  applyFilter(filterValue: string) {
    this.dataSource1.filter = filterValue.trim().toLowerCase();
  }
}

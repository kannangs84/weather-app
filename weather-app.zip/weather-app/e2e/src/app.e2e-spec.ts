import { AppPage } from './app.po';

describe('weather App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome title', () => {
    page.navigateTo();
    expect(page.getTitleText()).toEqual('Welcome to Weather App!');
  });
});

export interface IBoard {
  id: string;
  name: string;
}
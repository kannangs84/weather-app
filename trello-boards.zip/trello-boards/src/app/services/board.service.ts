import { Injectable } from '@angular/core';
import { Board } from '../models/board';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
const apiUrl = "http://localhost:3000/boards/";

@Injectable({
  providedIn: 'root'
})

export class BoardService {
  constructor(private http: HttpClient) { }

  getBoards(): Observable<Board[]> {
    return this.http.get<Board[]>(apiUrl)
  }

  getBoard(id: string): Observable<Board> {
    console.log('getboard');
    return this.http.get<Board>(apiUrl + id).pipe(
      tap(_ => console.log(`Fetched Board: id=${id}`)),
      catchError(this.handleError<Board>(`getBoard id=${id}`))
    );
  }

  addBoard(board: Board): Observable<Board> {
    return this.http.post<Board>(apiUrl, board, httpOptions).pipe(
      tap((board: Board) => console.log(`Added Board w/ name=${board.name}`)),
      catchError(this.handleError<Board>('addBoard'))
    );
  }

  updateBoard(board: Board): Observable<Board> {
    return this.http.put<Board>(apiUrl + board.id, httpOptions).pipe(
      tap(_ => console.log(`Updated Board: name=${board.name}`)),
      catchError(this.handleError<Board>(`Updated name=${board.name}`))
    );
  }

  deleteBoard(board: Board): Observable<Board> {
    return this.http.delete<Board>(apiUrl + board.id, httpOptions).pipe(
      tap(_ => console.log(`Deleted Board: name=${board.name}`)),
      catchError(this.handleError<Board>(`deleteBoard name=${board.name}`))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}

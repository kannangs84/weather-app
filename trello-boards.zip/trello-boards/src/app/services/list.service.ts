import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { List } from '../models/list';
import { Card } from '../models/card';

const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
const listApi = "http://localhost:3000/lists/";

@Injectable({
  providedIn: 'root'
})

export class ListService {
  constructor(private http: HttpClient) { }

  getLists(id: string): Observable<List[]> {
    return this.http.get<List[]>(listApi + id).pipe(
      tap(_ => console.log('Fetched Board Lists')),
      catchError(this.handleError('getLists', []))
    );
  }

  addList(list: List): Observable<List> {
    console.log(list);
    return this.http.post<List>(listApi, list, httpOptions).pipe(
      tap((list: List) => console.log(`Added List w/ name=${list.name}`)),
      catchError(this.handleError<List>('addList'))
    )
  }

  updateList(list: List): Observable<List> {
    return this.http.put<List>(listApi, list, httpOptions).pipe(
      tap(_ => console.log(`Updated List: name=${list.name}`)),
      catchError(this.handleError<List>(`updateList name=${list.name}`))
    );
  }

  deleteList(list: List): Observable<List> {
    return this.http.delete<List>(listApi + list.id, httpOptions).pipe(
      tap(_ => console.log(`Deleted List: name=${list.name}`)),
      catchError(this.handleError<List>(`deleteList name=${list.name}`))
    );
  }

  //***** CARDS *****//
  addCard(listID: string, card: Card): Observable<Card> {
    console.log(listID);
    console.log(card);
    return this.http.post<Card>(listApi, { listID, card }, httpOptions).pipe(
      tap((card: Card) => console.log(`Added Card w/ name=${card}`)),
      catchError(this.handleError<Card>('addCard'))
    );
  }

  updateCard(listID: string, cardLastName: string, card: Card): Observable<Card> {
    return this.http.put<Card>(listApi, { listID, cardLastName, card }, httpOptions).pipe(
      tap(_ => console.log(`Updated List: name=${card.text}`)),
      catchError(this.handleError<Card>(`updateList name=${card.text}`))
    );
  }

  deleteCard(listID: string, card: Card): Observable<Card> {
    return this.http.post<Card>(listApi, { listID, card }, httpOptions).pipe(
      tap(_ => console.log(`Deleted Card: name=${card.text}`)),
      catchError(this.handleError<Card>(`deleteCard name=${card.text}`))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}

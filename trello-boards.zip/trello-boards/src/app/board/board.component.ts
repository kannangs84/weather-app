import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Board } from '../models/board';
import { List } from '../models/list';
import { Card } from '../models/card';

import { BoardService } from '../services/board.service';
import { ListService } from '../services/list.service';

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.scss']
})

export class BoardComponent implements OnInit {
  board: Board;
  lists: List[];
  addingCard: boolean = false;

  constructor(private route: ActivatedRoute, private boardService: BoardService, private listService: ListService) { }

  ngOnInit() {
    this.getBoard();
    this.getLists();
  }

  getBoard(): void {
    const id = this.route.snapshot.params['id'];
    console.log(id);
    this.boardService.getBoard(id).subscribe(board => this.board = board);
  }

  getLists(): void {
    const boardID = this.route.snapshot.params['id'];
    this.listService.getLists(boardID).subscribe(lists => {
      this.lists = lists;
      console.log(this.lists);
    });
  }

  addList(name: string) {
    const boardID = this.route.snapshot.params['id'];
    name = name.trim();
    if(!name) { return; }
    this.listService.addList( {boardID: boardID, name: name, cards: [] } as List).subscribe(list => {
      console.log(list);
      this.lists.push(list);
    });
  }

  deleteListHandler(list: List) {
    this.listService.deleteList(list).subscribe(deletedList => {
      let listIndex = this.lists.indexOf(list);
      if(listIndex != -1) {
        this.lists.splice(listIndex, 1);
      }
    });
  }

  updateListHandler(list: List) {
    this.listService.updateList(list).subscribe(list => { });
  }
}

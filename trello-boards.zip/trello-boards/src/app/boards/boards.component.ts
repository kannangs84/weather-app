import { Component, OnInit } from '@angular/core';
import { Board } from '../models/board';
import { HttpClient } from "@angular/common/http";
import { Store, select } from '@ngrx/store';
import { State } from '../store/states';

import * as BoardActions from '../store/actions';
import { BoardService } from '../services/board.service';

@Component({
  selector: 'app-boards',
  templateUrl: './boards.component.html',
  styleUrls: ['./boards.component.scss']
})
export class BoardsComponent implements OnInit {
  boards: Board[];
  editingBoard: Board;

  constructor(private http: HttpClient, private boardService: BoardService, private store: Store<State>) { }

  ngOnInit() {
    this.getBoards();
  }

  getBoards() {
    //this.store.dispatch(BoardActions.loadAllSuccess({ payload: this.boards }))
    // this.boardService.getBoards().subscribe(boards => this.boards = boards);
  }

  addBoard(name: string) {
    name = name.trim();
    if (!name) { return; }
    console.log(this.store);
    this.store.dispatch(BoardActions.createBoard({ payload: name }))
    // this.boardService.addBoard({ name: name } as Board).subscribe(board => {
    //   this.boards.push(board);
    // });
  }

  editBoard(board: Board) {
    if (!this.editingBoard) { this.editingBoard = board; }
    else if (this.editingBoard == board) { this.editingBoard = null; }
    else { this.editingBoard = board; }
  }

  updateBoard(board: Board) {
    if (!board) { return; }
    // this.boardService.updateBoard(board).subscribe(board => { });
  }

  deleteBoard(board: Board) {
    if (!board) { return; }
    // this.boardService.deleteBoard(board).subscribe(deletedBoard => {
    //   let boardIndex = this.boards.indexOf(board);
    //   if (boardIndex != -1) {
    //     console.log('yessss');
    //     this.boards.splice(boardIndex, 1);
    //   }
    // });
  }

}

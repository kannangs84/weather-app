import { createFeatureSelector, createSelector } from '@ngrx/store';

import { State, featureName, adapter } from '../states';

/**
 * Selectors
 */
const getBoardState = createFeatureSelector<State>(featureName);
const { selectAll, selectEntities } = adapter.getSelectors();

export const getLoading = createSelector(
  getBoardState,
  state => state.loading
);

// export const getError = createSelector(
//   getBoardState,
//   state => state.error
// );

// export const getSelectedId = createSelector(
//   getBoardState,
//   state => state.selectedId
// );
import { Action, createReducer, on } from '@ngrx/store';

// import { State, initialState, adapter } from '../states';
import * as BoardActions from '../actions';

import { Board } from '../../models/board';

export interface State {
  loaded: boolean;
  loading: boolean;
  boards: string[];
}

const initialState: State = {
  loaded: false,
  loading: false,
  boards: [],
};

const boardReducer = createReducer(
  initialState,
  on(BoardActions.loadAll, state => ({
    ...state, 
    loading: true,
  })),
  // on(BoardActions.loadAllSuccess, (state, { boards }) => ({
  //   ...state,
  //   loading: false, 
  //   loaded: true,
  //   boards: boards.map(board => board.id),
  // })),
  on(BoardActions.createBoard, state => {
    console.log(state);
    return {
      ...state,
      boards: [...state.boards],
    }    
  }),
  on(BoardActions.createBoardSuccess, (state, { boards }) => {
    console.log(state);
    return {
      ...state,
      boards: [...state.boards, boards.id],
    };
  }),
  on(BoardActions.createBoardFailure, (state, { error }) => {
    console.log(state);
    return { ...state, loading: false, error };
  })
);

/**
 * Reducer
 * @param state State
 * @param action Action
 */
export function reducer(state: State | undefined, action: Action) {
  console.log('Reducers-=============')
  return boardReducer(state, action);
}

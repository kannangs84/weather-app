import { createAction, props } from '@ngrx/store';
import { Board } from '../../models/board';

export const loadAll = createAction(
  '[BOARD] Load All'
);

export const loadAllSuccess = createAction(
  '[BOARD] Load All success',
   props<{ payload: Board }>()
);

export const loadAllFailure = createAction(
  '[Todo API] Load All Failure',
  props<{ error: any }>()
);

export const createBoard = createAction(
  '[BOARD] Create Board',
  props<{ payload: string }>()
);

export const createBoardSuccess = createAction(
  '[BOARD] Create Board Success',
   props<{ boards: Board }>()
);

export const createBoardFailure = createAction(
  '[Todo API] Create Board Failure',
  props<{ error: any }>()
);

export const deleteBoard = createAction(
  '[BOARD] Delete Board',
   props<{ id: string }>()
);

export const deleteBoardSuccess = createAction(
  '[BOARD] Delete Board Success',
   props<{ id: string }>()
);

export const deleteBoardFailure = createAction(
  '[Todo API] Delete Board Failure',
  props<{ error: any }>()
);

import { Injectable } from '@angular/core';
import { Actions, ofType, createEffect } from '@ngrx/effects';
import { of } from 'rxjs';
import { map, tap, concatMap, switchMap, catchError, mergeMap } from 'rxjs/operators';

import * as BoardActions from '../actions';

/**
 * Todo effects
 */
@Injectable()
export class BoardEffects {
  store: any;
  boards: [];

  // loadAll$ = createEffect(() =>
  //   this.actions$.pipe(
  //     ofType(BoardActions.loadAll),
  //     switchMap(({ offset, limit }) =>
  //       this.todoService.findAll(offset, limit).pipe(
  //         map(result => BoardActions.loadAllSuccess({ boards: result })),
  //         catchError(error => of(BoardActions.loadAllFailure({ error })))
  //       )
  //     )
  //   )
  // );
  // create$ = createEffect(() =>
  //   this.actions$.pipe(
  //     ofType(BoardActions.createBoard),
  //     mergeMap(() => this.store),
  //     catchError((error ) => { console.log("HELLO"); return})
  //   )
  // );

  // performLogin() {
  //   return this.store
  //   .pipe(map((store) => console.log(store)));
  // }

  // create$ = createEffect(() =>
  //   this.actions$.pipe(
  //     map(result => BoardActions.createBoardSuccess({ boards: Board[] })),
  //     catchError(error => of(BoardActions.createBoardFailure({ error })))       
  //   )    
  // );

  constructor(
    private actions$: Actions
  ) {}

}

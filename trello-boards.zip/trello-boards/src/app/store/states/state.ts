import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';

import { Board } from '../../models/board';

/**
 * Feature name
 */
export const featureName = 'board';

/**
 * State
 */
export interface State extends EntityState<Board> {
  loading: boolean;
  boards?: Board[];
}

/**
 * Adapter
 */
export const adapter = createEntityAdapter<Board>();

/**
 * Initial state
 */
export const initialState: State = adapter.getInitialState({
  loading: false,
  boards: [{ 
    id: null,
    name: null
  }]  
});

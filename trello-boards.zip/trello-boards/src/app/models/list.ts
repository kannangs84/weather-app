export class List {
  id: string;
  boardID: string;
  name: string;
  cards: any[];
}
export class Card {
  text: string;
}